/*
 * Regista os movimentos das contas
 */
package projetosistemabancario;

/**
 * @author Rodrigo Hay
 */
public class Movimentos {

    public void GravaMovimento() {


        }
    }
